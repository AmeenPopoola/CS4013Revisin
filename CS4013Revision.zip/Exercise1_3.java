

public class Exercise1_3 {
    public static void main (String [] args) {
       System.out.println("    ]     A    V     V    A");
       System.out.println("    ]    A A    V   V    A A");
       System.out.println("]   ]   AAAAA    V V    AAAAA");
       System.out.println(" ] ]   A     A    V    A     A");
        
        
        
        
        
        
        
    }
}
  