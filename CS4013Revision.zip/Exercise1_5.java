

public class Exercise1_5 {
    public static void main(String[]args){
     double numerator = (7.5 * 2.5) - (1.5 * 3) ;
     double denominator = 53.5 -2.5;
     
     double result = numerator/ denominator;
     
     System.out.println(result);
    }
}